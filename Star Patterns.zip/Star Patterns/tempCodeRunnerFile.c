  // for(int i=0;i<5;i++)
    // {
    //     for(int k=0;k<i;k++)
    //     {
    //         printf(" ");
    //     }
    //     for(int j=0;j<(2*(5-i))-1;j++)
    //     {
    //         printf("*");
    //     }
    //     printf("\n");
    // }